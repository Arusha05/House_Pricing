# PRODIGI_ML_05
Task 05: Develop a model that can accurately recognize food items from images and estimate their calorie content and enabling users to track their dietary intake   and make informed food choices
